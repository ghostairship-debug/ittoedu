# r20-contextual-authoring 轻量上下文共编集成

- Status / Owner: active / Codex
- Outcome / Evidence: 用户已授权推进2.0；首批并行补丁的源文映射仍会扩大选区，类型及聊天适配尚未统一，须完成真实入口和版本失效闭环。
- Write scope: src/shared/document/、src/renderer/document/、src/renderer/documentFiles/、src/renderer/ui/chat/、src/renderer/lessonWorkspace/、FlowWorkspace.tsx及直接测试；主会话唯一writer，先前四个子任务已停止。
- Write locks: contracts-schema, chat-ui, workspace-shell, authoring-flow
- Acceptance: Markdown及Flow选择成为精确目标，卡片与聊天同一冻结提交路径，stale零写入，人工保存/重开/撤销不回退；2.0其余生产门有真实证据才晋升。
- Validation: 定向选区/源文/控制器测试；typecheck；真实UI选择、修改、保存重开和停止验收。
