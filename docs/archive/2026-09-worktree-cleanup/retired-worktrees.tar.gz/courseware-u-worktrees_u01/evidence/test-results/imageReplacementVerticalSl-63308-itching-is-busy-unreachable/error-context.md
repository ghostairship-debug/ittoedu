# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: imageReplacementVerticalSlice.spec.ts >> ARCH-1 VS-06 image replacement desktop regression >> deferred cross-location completion is stale and project switching is busy-unreachable
- Location: tests\e2e\imageReplacementVerticalSlice.spec.ts:567:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('footer.status-bar')
Expected substring: "已选：slide-intro-hero"
Received string:    "已打开“ARCH-0 代表工程 · Slide-heavy”判别式导入·6 个节点·未选择节点·工程已命名"
Timeout: 10000ms

Call log:
  - Expect "toContainText" with timeout 10000ms
  - waiting for locator('footer.status-bar')
    23 × locator resolved to <footer class="status-bar" aria-live="polite">…</footer>
       - unexpected value "已打开“ARCH-0 代表工程 · Slide-heavy”判别式导入·6 个节点·未选择节点·工程已命名"

```

```yaml
- text: 已打开“ARCH-0 代表工程 · Slide-heavy” 判别式导入 · 6 个节点 · 未选择节点 · 工程已命名
```

# Test source

```ts
  366 | async function deferredImageDialogPhase(app: ElectronApplication): Promise<string> {
  367 |   return app.evaluate(() => {
  368 |     const host = globalThis as unknown as {
  369 |       __VS06_IMAGE_DIALOG__?: { phase?: string }
  370 |     }
  371 |     return host.__VS06_IMAGE_DIALOG__?.phase ?? 'missing'
  372 |   })
  373 | }
  374 | 
  375 | async function releaseDeferredImageDialog(app: ElectronApplication): Promise<void> {
  376 |   await app.evaluate(({ dialog }) => {
  377 |     type State = {
  378 |       phase: 'armed' | 'pending' | 'resolved'
  379 |       selectedPath: string
  380 |       previous: typeof dialog.showOpenDialog
  381 |       resolve?: (value: Electron.OpenDialogReturnValue) => void
  382 |     }
  383 |     const host = globalThis as unknown as { __VS06_IMAGE_DIALOG__?: State }
  384 |     const state = host.__VS06_IMAGE_DIALOG__
  385 |     if (!state || state.phase !== 'pending' || !state.resolve) {
  386 |       throw new Error('VS-06 deferred image dialog is not pending')
  387 |     }
  388 |     dialog.showOpenDialog = state.previous
  389 |     state.phase = 'resolved'
  390 |     state.resolve({ canceled: false, filePaths: [state.selectedPath] })
  391 |   })
  392 | }
  393 | 
  394 | async function cancelDeferredImageDialog(app: ElectronApplication): Promise<void> {
  395 |   await app.evaluate(({ dialog }) => {
  396 |     type State = {
  397 |       phase: 'armed' | 'pending' | 'resolved'
  398 |       previous: typeof dialog.showOpenDialog
  399 |       resolve?: (value: Electron.OpenDialogReturnValue) => void
  400 |     }
  401 |     const host = globalThis as unknown as { __VS06_IMAGE_DIALOG__?: State }
  402 |     const state = host.__VS06_IMAGE_DIALOG__
  403 |     if (!state) return
  404 |     dialog.showOpenDialog = state.previous
  405 |     if (state.phase === 'pending') {
  406 |       state.resolve?.({ canceled: true, filePaths: [] })
  407 |     }
  408 |     delete host.__VS06_IMAGE_DIALOG__
  409 |   })
  410 | }
  411 | 
  412 | async function openProject(
  413 |   app: ElectronApplication,
  414 |   page: Page,
  415 |   projectPath: string,
  416 |   expectedLocationTestId: string,
  417 | ): Promise<void> {
  418 |   await patchDialogs(app, { projectOpen: projectPath })
  419 |   await page.getByRole('button', { name: '打开工程（Ctrl+O）' }).click()
  420 |   await showEditorPanel(page, '页面与图层')
  421 |   await expect(page.getByTestId(expectedLocationTestId)).toBeVisible({ timeout: 15_000 })
  422 | }
  423 | 
  424 | async function showEditorPanel(
  425 |   page: Page,
  426 |   name: '页面与图层' | '属性与素材',
  427 | ): Promise<void> {
  428 |   const button = page.getByRole('button', { name, exact: true })
  429 |   await expect(button).toBeVisible()
  430 |   if (await button.getAttribute('aria-expanded') !== 'true') await button.click()
  431 | }
  432 | 
  433 | async function saveAs(
  434 |   app: ElectronApplication,
  435 |   page: Page,
  436 |   path: string,
  437 |   otherPaths: DialogPaths = {},
  438 | ): Promise<void> {
  439 |   await patchDialogs(app, { ...otherPaths, projectSave: path })
  440 |   await page.getByRole('button', { name: '另存为' }).click()
  441 |   await expect.poll(
  442 |     () => existsSync(path) ? statSync(path).size : 0,
  443 |     { timeout: 15_000 },
  444 |   ).toBeGreaterThan(100)
  445 | }
  446 | 
  447 | async function selectSlideImage(page: Page, itemId = 'slide-intro-hero'): Promise<void> {
  448 |   const fixture = openCourseProjectArchive(new Uint8Array(readFileSync(slideSourcePath)))
  449 |   const target = fixture.project.surfaces.flatMap((surface) => surface.type === 'slide'
  450 |     ? surface.scenes.flatMap((scene) => scene.layerItems
  451 |       .filter((item) => item.layerItemId === itemId)
  452 |       .map((item) => ({ item, canvas: surface.canvas })))
  453 |     : []).at(0)
  454 |   if (!target || target.item.frame.mode !== 'absolute') {
  455 |     throw new Error(`Missing absolute Slide image fixture geometry: ${itemId}`)
  456 |   }
  457 |   const canvas = page.getByTestId('canvas-stage').locator('canvas').first()
  458 |   await expect(canvas).toBeVisible()
  459 |   const bounds = await canvas.boundingBox()
  460 |   if (!bounds) throw new Error('Slide authoring canvas is not visible')
  461 |   const { frame } = target.item
  462 |   await page.mouse.click(
  463 |     bounds.x + ((frame.x + frame.width / 2) / target.canvas.width) * bounds.width,
  464 |     bounds.y + ((frame.y + frame.height / 2) / target.canvas.height) * bounds.height,
  465 |   )
> 466 |   await expect(page.locator('footer.status-bar')).toContainText(`已选：${itemId}`)
      |                                                   ^ Error: expect(locator).toContainText(expected) failed
  467 |   await showEditorPanel(page, '属性与素材')
  468 |   await expect(page.getByTestId('properties-tab')
  469 |     .getByRole('button', { name: '替换图片', exact: true })).toBeVisible()
  470 | }
  471 | 
  472 | async function makeBaselineBannerExportable(page: Page): Promise<void> {
  473 |   await showEditorPanel(page, '页面与图层')
  474 |   await page.getByRole('button', { name: /全局层（全课）/ }).click()
  475 |   await showEditorPanel(page, '属性与素材')
  476 |   await page.getByRole('tab', { name: '图层' }).click()
  477 |   const banner = page.getByTestId('node-item-slide-global-banner')
  478 |   await expect(banner).toBeVisible()
  479 |   await banner.locator('.node-name').click()
  480 |   const height = page.getByTestId('properties-tab').getByLabel('高', { exact: true })
  481 |   await expect(height).toBeVisible()
  482 |   await height.fill('80')
  483 |   await height.press('Enter')
  484 | }
  485 | 
  486 | async function enterTryRun(page: Page): Promise<void> {
  487 |   const button = page.getByRole('group', { name: '画布模式' })
  488 |     .getByRole('button', { name: '当前位置试运行', exact: true })
  489 |   await button.click()
  490 |   await expect(button).toHaveAttribute('aria-pressed', 'true')
  491 | }
  492 | 
  493 | async function returnToEdit(page: Page): Promise<void> {
  494 |   await page.getByRole('group', { name: '画布模式' })
  495 |     .getByRole('button', { name: '编辑状态', exact: true })
  496 |     .click()
  497 | }
  498 | 
  499 | async function exportHtmlAndWeb(
  500 |   app: ElectronApplication,
  501 |   page: Page,
  502 | ): Promise<void> {
  503 |   await patchDialogs(app, { htmlSave: htmlPath, webPackageSave: webPackagePath })
  504 |   await page.getByTestId('export-menu-trigger').click()
  505 |   await page.getByTestId('export-single-html').click()
  506 |   const htmlPreflight = page.getByRole('alertdialog', { name: '单 HTML 导出预检' })
  507 |   await expect(htmlPreflight).toContainText('0 个错误')
  508 |   await htmlPreflight.getByRole('button', { name: '继续导出' }).click()
  509 |   await expect.poll(() => existsSync(htmlPath) ? statSync(htmlPath).size : 0, {
  510 |     timeout: 30_000,
  511 |   }).toBeGreaterThan(1_000)
  512 | 
  513 |   await page.getByTestId('export-menu-trigger').click()
  514 |   await page.getByTestId('export-web-package').click()
  515 |   const webPreflight = page.getByRole('alertdialog', { name: '网页包 导出预检' })
  516 |   await expect(webPreflight).toContainText('0 个错误')
  517 |   await webPreflight.getByRole('button', { name: '继续导出' }).click()
  518 |   await expect.poll(() => existsSync(webPackagePath) ? statSync(webPackagePath).size : 0, {
  519 |     timeout: 30_000,
  520 |   }).toBeGreaterThan(1_000)
  521 | }
  522 | 
  523 | function unexpectedConsoleErrors(errors: readonly string[]): string[] {
  524 |   return errors.filter((message) => !(
  525 |     message.includes('UserFacingError') &&
  526 |     (
  527 |       message.includes('编辑会话已过期')
  528 |       || message.includes('当前页面或呈现状态已改变')
  529 |       || message.includes('工程已发生变化')
  530 |     )
  531 |   ))
  532 | }
  533 | 
  534 | function expectCleanDiagnostics(
  535 |   diagnostics: Diagnostics,
  536 |   options: { allowExpectedStaleError?: boolean } = {},
  537 | ): void {
  538 |   expect(diagnostics.pageErrors).toEqual([])
  539 |   expect(diagnostics.externalRequests).toEqual([])
  540 |   expect(
  541 |     options.allowExpectedStaleError
  542 |       ? unexpectedConsoleErrors(diagnostics.consoleErrors)
  543 |       : diagnostics.consoleErrors,
  544 |   ).toEqual([])
  545 |   expect(diagnostics.consoleWarnings.filter((message) => !(
  546 |     message.includes('A props object containing a "key" prop is being spread into JSX') ||
  547 |     message.includes('WebGL: INVALID_VALUE: texImage2D: bad image data')
  548 |   ))).toEqual([])
  549 | }
  550 | 
  551 | test.describe.serial('ARCH-1 VS-06 image replacement desktop regression', () => {
  552 |   const sourceHashesBefore = fixtureHashes()
  553 | 
  554 |   test.beforeAll(() => {
  555 |     mkdirSync(evidenceDirectory, { recursive: true })
  556 |     const manifest = JSON.parse(readFileSync(fixtureManifestPath, 'utf8')) as FixtureManifest
  557 |     for (const fixture of manifest.fixtures) {
  558 |       const path = join(fixtureDirectory, fixture.filename)
  559 |       expect(sha256(path)).toBe(fixture.sha256)
  560 |     }
  561 |   })
  562 | 
  563 |   test.afterAll(() => {
  564 |     expect(fixtureHashes()).toEqual(sourceHashesBefore)
  565 |   })
  566 | 
```